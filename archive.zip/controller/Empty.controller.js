sap.ui.define(["odataui5project/controller/BaseController"],function(t){"use strict";return t.extend("odataui5project.controller.Empty",{})});
//# sourceMappingURL=Empty.controller.js.map