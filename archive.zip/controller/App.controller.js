sap.ui.define(["odataui5project/controller/BaseController"],function(e){"use strict";return e.extend("odataui5project.controller.App",{})});
//# sourceMappingURL=App.controller.js.map