sap.ui.define(['odataui5project/controller/BaseController'],
 function(BaseController) {
    'use strict';
    return BaseController.extend('odataui5project.controller.Empty',{

    });
});